﻿using GameBusiness;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameBusiness
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameCharacter charachter = new GameCharacter(); //Nieuwe charachter aanmaken

            Console.WriteLine("Wat is jouw naam?"); //Vraag voor de naam

            String name = Console.ReadLine(); //Leest de naam in van de gebruiker

            charachter.setName(name); //Zet de naam van de character

            Console.WriteLine(charachter.showStats()); //Toont de stats (eigenlijk informatie over gebruiker)

            charachter.setLevel(charachter.getLevel() + 1); //Verhoogt de level met 1

            charachter.setHealth(charachter.getHealth() + 20); //Verhoogt de health met 20

            Console.WriteLine("Level zal met verhogen met 1, en health met 20"); //Toont bericht dat alles klopt

            Console.WriteLine(charachter.showStats()); //Toont de stats nog een keer om alles te controleren

        }
    }
}
