﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization.Metadata;
using System.Threading.Tasks;

namespace GameBusiness
{
    internal class GameCharacter
    {
        //Velden
        private String name; //Naam van charachter
        private int level; //Level van characher
        private int health; //Health van charachter

        //Constructor inisialisatie
        public GameCharacter()
        {

            this.name = ""; //Nieuwe naam van charachter
            this.level = 1; //Nieuwe level van charachter
            this.health = 100; //Nieuwe health van charachter

        }

        public String getName()
        {

            return name;

        }
        public int getLevel()
        {

            return level;

        }


        public int getHealth()
        {

            return health;

        }

        public void setName(String name)
        {

            this.name = name;

        }

        public void setLevel(int level)
        {

            this.level = level;

        }

        public void setHealth(int health)
        {

            this.health = health;

        }

        //Methode ShowStats geeft het naam, level en health terug.
        public String showStats()
        {

            return "Speler: " + getName() + " Level: " + getLevel() + " Health: " + getHealth();
            //Naam, level en health terug krijgen
        }
    }
}