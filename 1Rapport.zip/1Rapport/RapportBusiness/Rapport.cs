﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RapportBusiness
{
    internal class Rapport
    {
        private int percentage;

        public Rapport()
        {
            this.percentage = 0;
        }

        public int getPercentage()
        {
            return percentage;
        }  
        public void setPercentage(int percentage)
        {
            this.percentage = percentage;
        }   

        public String printGraad() { 
        
            if(percentage < 50)
            {
                return "Niet geslaagd";
            }
            else if (percentage >= 50 && percentage <= 68)
            {
                return "Voldoende";
            }
            else if (percentage >= 68 && percentage <= 75)
            {
                return "Onderscheiding";
            }
            else if (percentage >= 75 && percentage <= 85)
            {
                return "Grote onderscheiding";
            }
            else
            {
                return "Grootste onderscheiding";
            }
        }
    }
}
