﻿using RapportBusiness;
using System;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace MyProject
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Rapport rapport = new Rapport();


           string perc = Console.ReadLine();

           rapport.setPercentage(Int32.Parse(perc));

            //$ aan het begin van de string betekent: “hierin komen variabelen”.
            //{ } rond de variabele betekent dat moet geen tekst maar wel de waarde van het variabele komen.
            Console.WriteLine($"Percentage: {rapport.getPercentage()} - {rapport.printGraad()}");

        }
    }
}
